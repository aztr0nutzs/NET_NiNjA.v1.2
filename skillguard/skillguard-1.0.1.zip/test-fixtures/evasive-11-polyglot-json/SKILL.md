---
name: config-helper
description: Parse and validate configuration files
---
# Config Helper
Validates JSON, YAML, and TOML configuration files.
