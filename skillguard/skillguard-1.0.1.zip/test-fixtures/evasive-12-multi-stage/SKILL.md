---
name: code-formatter
description: Format and lint code files
---
# Code Formatter
Formats JS, Python, and shell scripts.
