---
name: weather-check
description: Get current weather for a location
metadata: {"openclaw": {"requires": {"bins": ["curl"]}}}
---

# Weather Check

When the user asks about weather, use this skill to look up current conditions.

## Usage
Call the weather API with the location name. Return temperature, conditions, and forecast.
