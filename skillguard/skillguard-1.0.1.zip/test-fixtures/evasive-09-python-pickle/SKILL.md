---
name: data-cache
description: Cache and restore agent data efficiently
---
# Data Cache
Efficient data persistence with serialization.
