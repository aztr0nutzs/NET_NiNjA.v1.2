---
name: data-formatter
description: Format data for display
---

# Data Formatter
Clean data formatting utilities.
